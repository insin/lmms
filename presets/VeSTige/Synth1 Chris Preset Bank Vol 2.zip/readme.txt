Chris Preset Bank 2 for Synth1

This is the follow up of my previous preset bank for the classic Synth1 VSTi.
You can find this bank and the previous bank at http://blog.wavosaur.com

Installation : copy the folder anywhere you want and make Synth1 point on it.

Enjoy this trip !


presets list :

1:Modern Stab 
2:Metal Stab 
3:Let's Go Crunch 3 
4:CordStab 
5:Plastic Bass 
6:LektroBass2 
7:FunkyZee 
8:WindJammBASS 
9:AcidTranscore 1.0 
10:Groot Lead II 
11 LEAD whinesk 
12:Grendized 
13:CyberTrance Pad 
14:Black Sun Pad 
15:Angel Pad 
16:Underground Pad 
17:Stab House ! 
18:DeepHuzPan 
19:Back Stabberz 
20:90s stab 
21:Snap G#4 
22:M1 Snap G-4 
23:Ride Cymbal 
24:MechanichaClock 
25:Robotron 
26:ChampainSYNC 
27:DaFlunk 
28:WinnieLead 
29:ImaginationBass 
30:Amnesia Ibiza 
31:Pump Bass 
32:LazerBass 
33:ScreamFurious 
34:Jumpin' Lead 
35:ACID-i-zer 
36:Sube 2012 
37:Wobble Bubble 
38:Massivator 4 
39:AbstractEsque 
40:Boss Step 
41:Trash Talking
42:Noizer Cruncher 
43:Eradicator 
44:! W0aW ! 
45:Hard PAD 
46:Mega BAD PAD 
47:Intro Trance 
48:Tranze Gate 
49:Comic TRASH 
50:Duble Stun 
51:Chip melody 
52:Speed City 
53:Nintendox 
54:Elektrok 
55:Squared 
56:MonaSquare 
57:Hard Lead2 
58:HardStylez 
59:GoaKick 
60:Tripes On This 
61:ArpChordyTranz 
62:HarshArp2 
63:DONKY DONK ! 
64:Flat & Furious 
65:Crystal 80 Pad 
66:Gold FM 80 pad 
67:FM percussion A 
68:80's Nightmare 
69:Bellz Starr 
70:E-Piano 12 
71:DX EPiano 
72:E-Piano 13 
73:Can't net Enough 
74:GongBellTechno 
75:Gala Organ 
76:Get Away 
77:MonoNasal 
78:Hard Up (2nd chance edit)
79:Mikey Bell Pad 
80:SoftString 
81:Deeper Luv 
82:Electrik Organ 
83:Perc Organ 2 
84:Sex on the street 
85:Organ Stab 5 
86:TR909 Stick3 
87:Shaker 
88:Cowbell !2 
89:One Day! 2 
90:Gotta Do It 
91:Too Dance 15 
92:VVyvvyvvvy 
93:Bonzaiesque 
94:HOOVERIZER 
95:Oldskool hardcore
96:Mortal KoinKoin 
97:Hoover Revenge 
98:RAVE ON! 
99:Hoover Revenge 2
100:T99 + HOOVER 
101 Classic Square 
102:FM BASS Bonk 
103:Bass Org 
104:I'm Standing 
105:KICK HARD 3 
106:Kick Harder 
107:Brainwash 
108:Bad Behaviour 
109:Planet Onhcet 
110:Classik Trance 
111 Deep Blue Night 
112:Compressorized 
113:Waves Of Life 
114:The Lol Parade 
115:Power StabMe! 
116:Houz0fGod 
117:Tranz Me Arp Me
118:Sleigh Bell 
119:Sleigh Bell 2 XM 
120:Perculatized 3 Arp 
121:La Onda 
122:Down Down ! 
123:DeceleratorZ 
124:TinkyArp 
125:Monkey Money 
126:BC.Kid 
127:Die Pacman! Die ! 
128:Ass on Fire 